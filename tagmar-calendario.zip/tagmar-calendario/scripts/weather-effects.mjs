import {environmentInfo, normalizeClimate} from "./weather.mjs";
import {fadeSeconds} from "./weather-transition.mjs";
import {getEnvironmentSettings} from './environment-settings.mjs';

const ID = "tagmar-calendario";

// IDs conferidos no CONFIG.weatherEffects do Foundry 14.369.
// undefined significa indisponível: não apagar um efeito por engano.
export function nativeWeatherEffect(weather, effects = {}) {
  if (!weather) return undefined;
  const choices = {
    clear: [""], cloudy: [""], overcast: [""],
    drizzle: ["rain"], rain: ["rain"], storm: ["rainStorm", "rain"],
    fog: ["fog"], snow: weather.wind >= 35 ? ["blizzard", "snow"] : ["snow"]
  };
  return choices[weather.condition]?.find(id => id === "" || Object.hasOwn(effects, id));
}

// Um GM grava o documento compartilhado, sem manipular diretamente o canvas.
// A fila relê cena/configuração após cada gravação, inclusive ao trocar de cena.
export function createWeatherEffectsSync({getGame, getDate, getEffects, getFadeSeconds = () => 0,
  sleep = ms => new Promise(resolve => setTimeout(resolve, ms)),
  newToken = () => globalThis.crypto.randomUUID(), onError = console.error}) {
  let pending = false, running, reportedFailure = false;
  return function sync() {
    pending = true;
    if (running) return running;
    running = Promise.resolve().then(async () => {
      while (pending) {
        pending = false;
        const game = getGame();
        if(game.settings?.get(ID,'scenePresetVersion')===0)continue; // Wait for the original-scene backup.
        const leader = game.users.filter(u => u.active && u.isGM).sort((a,b) => a.id.localeCompare(b.id))[0];
        if (!game.user?.isGM || leader?.id !== game.user.id) continue;
        const enabled = getEnvironmentSettings(game).weatherEnabled;
        // Ao desligar, liberar também efeitos deixados em cenas inativas.
        const scenes = enabled ? [game.scenes?.active] : [...new Set([
          game.scenes?.active, ...(game.scenes?.contents ?? [])
        ])];
        for (const scene of scenes) {
          if (!scene) continue;
          const config = normalizeClimate(scene.getFlag(ID, "climate"));
          const raw = scene.getFlag(ID, "weatherVisualState");
          const owned = raw && typeof raw.previous === "string" && typeof raw.applied === "string" ? raw : null;
          const effects = getEffects() ?? {};
          const current = scene.weather ?? "";
          let changes;
          if (!enabled || (!config.indoor && (!config.visualEffects || config.mode === "off"))) {
            if (!owned) continue;
            changes = {[`flags.${ID}.-=weatherVisualState`]: null};
            // Não sobrescrever uma escolha manual feita após nosso último efeito.
            if (current === owned.applied) {
              const previous = owned.previous === "" || Object.hasOwn(effects, owned.previous) ? owned.previous : "";
              if (current !== previous) changes.weather = previous;
            }
          } else if(config.indoor) {
            if(current==='')continue;
            changes={weather:'',[`flags.${ID}.weatherVisualState`]:{previous:owned?.previous??current,applied:''}};
          } else {
            const target = nativeWeatherEffect(environmentInfo(scene, getDate(), game.time.worldTime,game.world).weather, effects);
            if (target === undefined || (current === target && (!owned || owned.applied === target))) continue;
            changes = {
              weather: target,
              [`flags.${ID}.weatherVisualState`]: {previous: owned?.previous ?? current, applied: target}
            };
          }
          let prepared = false;
          try {
            const seconds = fadeSeconds(getFadeSeconds());
            if (scene === game.scenes?.active && 'weather' in changes && changes.weather !== current && seconds > 0) {
              // Aviso compartilhado chega aos clientes antes da atualização nativa
              // que redesenha o canvas. Não usar socket sem autenticação de remetente.
              await scene.update({[`flags.${ID}.weatherTransition`]: {
                token: newToken(), from: current, target: changes.weather, seconds
              }}, {tagmarWeatherEffects: true, tagmarWeatherPrepare: true});
              prepared = true;
              if (current) await sleep(seconds * 500);
              const latest = getGame();
              const latestLeader = latest.users.filter(u => u.active && u.isGM).sort((a,b) => a.id.localeCompare(b.id))[0];
              const latestConfig = normalizeClimate(scene.getFlag(ID, 'climate'));
              const latestEnabled = getEnvironmentSettings(latest).weatherEnabled;
              const latestTarget = !latestEnabled ? changes.weather : latestConfig.indoor ? '' : latestConfig.visualEffects && latestConfig.mode !== 'off'
                ? nativeWeatherEffect(environmentInfo(scene, getDate(), latest.time.worldTime,latest.world).weather, getEffects() ?? {}) : changes.weather;
              if (!latest.user?.isGM || latestLeader?.id !== latest.user.id || latest.scenes?.active !== scene
                || latestEnabled !== enabled || scene.weather !== current || JSON.stringify(latestConfig) !== JSON.stringify(config) || latestTarget !== changes.weather) {
                await scene.update({[`flags.${ID}.-=weatherTransition`]: null}, {tagmarWeatherEffects:true, tagmarWeatherCancel:true});
                prepared = false;
                pending = true;
                continue;
              }
              changes[`flags.${ID}.-=weatherTransition`] = null;
            }
            await scene.update(changes, {tagmarWeatherEffects: true});
            prepared = false;
            reportedFailure = false;
          } catch (error) {
            if (prepared) {
              try { await scene.update({[`flags.${ID}.-=weatherTransition`]: null}, {tagmarWeatherEffects:true, tagmarWeatherCancel:true}); }
              catch { /* O watchdog visual dos clientes restaura a opacidade. */ }
            }
            pending = false;
            if (!reportedFailure) onError(error);
            reportedFailure = true;
          }
        }
      }
    }).finally(() => {
      running = undefined;
      if (pending) return sync();
    });
    return running;
  };
}
